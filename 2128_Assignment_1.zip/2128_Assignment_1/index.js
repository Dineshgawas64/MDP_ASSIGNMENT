require('./database/connection')
const Data = require('./database/model')

const user = {
    name1: 'Dinesh',
    Age: 22 
}

const data = async ()=>{
    await Data(user).save()
}

data()
